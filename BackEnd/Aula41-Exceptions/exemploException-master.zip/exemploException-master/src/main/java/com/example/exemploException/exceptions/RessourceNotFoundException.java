package com.example.exemploException.exceptions;

public class RessourceNotFoundException extends Exception{

    public RessourceNotFoundException(String message){
        super(message);
    }
}
