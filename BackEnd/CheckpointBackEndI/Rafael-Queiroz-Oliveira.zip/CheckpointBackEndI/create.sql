create table if not exists redehoteis (id int auto_increment primary key,
nomeFilial varchar(255),rua varchar(255),numero int,cidade varchar(255), estado varchar(255), cincoEstrelas int);