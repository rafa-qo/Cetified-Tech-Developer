package com.example.exemploException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploExceptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploExceptionApplication.class, args);
	}

}
