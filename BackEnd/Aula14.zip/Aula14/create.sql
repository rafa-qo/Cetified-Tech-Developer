create table if not exists medicamentos (id int auto_increment primary key,
nome varchar(255),lab varchar(255),qtde int,preco double);